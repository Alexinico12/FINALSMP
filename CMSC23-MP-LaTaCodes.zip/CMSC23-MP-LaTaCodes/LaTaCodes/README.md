# CMSC_23LABMP
A Restaurant Inventory System with GUI submitted as a final project for CMSC 23

BY:
BONIFACIO, Christian Jesse
MALUNES, Maria Estela Leonila
SALAZAR, Alexine Johnieco D.
SURBAN, Alyssa Nicole
