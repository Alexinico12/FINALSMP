package com.example.LaTaCodes;

/**
 * The Ingredients model is used by the setTable method in InventoryController
 * for setting up or defining the cell value properties of the table.
 */

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Ingredients {
    SimpleStringProperty sku;
    SimpleStringProperty name;
    SimpleStringProperty category;
    SimpleStringProperty brand;
    SimpleIntegerProperty amount;
    SimpleStringProperty unit;
    SimpleStringProperty typedesc;

    /**
     * This is a constructor method for the table's cell values
     * and their respective types.
     *
     * @param sku This is a constructor for the SKU of item/ingredient.
     * @param name This is a constructor for the name of item/ingredient.
     * @param category This is a constructor for the category of item/ingredient.
     * @param brand This is a constructor for the brand of item/ingredient.
     * @param amount This is a constructor for the weight or volume of item/ingredient.
     * @param typedesc This is a constructor for the type or description of item/ingredient.
     */
    public Ingredients (String sku, String name, String category, String brand, int amount, String unit, String typedesc){
        this.sku = new SimpleStringProperty(sku);
        this.name = new SimpleStringProperty(name);
        this.category = new SimpleStringProperty(category);
        this.brand = new SimpleStringProperty(brand);
        this.amount = new SimpleIntegerProperty(amount);
        this.unit = new SimpleStringProperty(unit);
        this.typedesc = new SimpleStringProperty(typedesc);
    }

    public String getSKU() {
        return sku.get();
    }

    public String getName() {
        return name.get();
    }

    public String getCategory() {
        return category.get();
    }

    public String getBrand() {
        return brand.get();
    }

    public int getAmount() {
        return amount.get();
    }

    public String getUnit() {
        return unit.get();
    }

    public String getTypeDesc() {
        return typedesc.get();
    }

    public void setSKU(String sku) {
        this.sku.set(sku);
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public void setCategory(String category) {
        this.category.set(category);
    }

    public void setBrand(String brand) {
        this.brand.set(brand);
    }

    public void setAmount(int amount) {
        this.amount.set(amount);
    }

    public void setUnit(String unit) {
        this.unit.set(unit);
    }

    public void setTypeDesc(String typedesc) {
        this.typedesc.set(typedesc);
    }
}
