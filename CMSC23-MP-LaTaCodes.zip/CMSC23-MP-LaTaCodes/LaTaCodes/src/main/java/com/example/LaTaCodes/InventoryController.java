package com.example.LaTaCodes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;

public class InventoryController {
    String[] units = {"pcs", "g", "mL"};
    @FXML
    private TextField srchField;
    @FXML
    private TextField skuField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField categField;
    @FXML
    private TextField brandField;
    @FXML
    private TextField amtField;
    @FXML
    public ComboBox<String> unitBox;
    @FXML
    private TextField typedescField;
    @FXML
    private TextField csvfileField;

    @FXML
    private Button AddItem, AddStockSKU, BulkAdd, UseStock, DeleteItem;

    @FXML
    private AnchorPane invPane;
    @FXML
    private TableView<Ingredients> invTable;
    @FXML
    private ObservableList<Ingredients> invTableData;
    @FXML
    private Stage stage;

    private ArrayList<Ingredients> arr;


    /**
     * This method is for setting the CSS of the buttons placed in the
     * inventory scene.
     */
    protected void setInvCSS() {
        AddItem.getStyleClass().add("add-item");
        AddStockSKU.getStyleClass().add("add-stockSKU");
        BulkAdd.getStyleClass().add("bulk-add");
        UseStock.getStyleClass().add("use-stock");
        DeleteItem.getStyleClass().add("delete-item");
    }

    /**
     * This method is called when the user clicks on the 'Check Inventory' button
     * and switches to the new stage and scene. This is for setting the table view
     * of the inventory list.
     */
    @FXML
    protected void setTable() {
        unitBox.getItems().addAll(units);
        invTableData = FXCollections.observableArrayList();
        invTable = new TableView<Ingredients>();

        TableColumn<Ingredients, String> column1 = new TableColumn<Ingredients, String>("SKU");
        TableColumn<Ingredients, String> column2 = new TableColumn<Ingredients, String>("Name");
        TableColumn<Ingredients, String> column3 = new TableColumn<Ingredients, String>("Category");
        TableColumn<Ingredients, String> column4 = new TableColumn<Ingredients, String>("Brand");
        TableColumn<Ingredients, Integer> column5 = new TableColumn<Ingredients, Integer>("Amount");
        TableColumn<Ingredients, String> column6 = new TableColumn<Ingredients, String>("Unit");
        TableColumn<Ingredients, String> column7 = new TableColumn<Ingredients, String>("Type/Description");

        column1.prefWidthProperty().bind(invTable.widthProperty().multiply(0.12));
        column2.prefWidthProperty().bind(invTable.widthProperty().multiply(0.20));
        column3.prefWidthProperty().bind(invTable.widthProperty().multiply(0.125));
        column4.prefWidthProperty().bind(invTable.widthProperty().multiply(0.125));
        column5.prefWidthProperty().bind(invTable.widthProperty().multiply(0.120));
        column6.prefWidthProperty().bind(invTable.widthProperty().multiply(0.10));
        column7.prefWidthProperty().bind(invTable.widthProperty().multiply(0.203));

        column1.setCellValueFactory(new PropertyValueFactory<Ingredients, String>("SKU"));
        column2.setCellValueFactory(new PropertyValueFactory<Ingredients, String>("Name"));
        column3.setCellValueFactory(new PropertyValueFactory<Ingredients, String>("Category"));
        column4.setCellValueFactory(new PropertyValueFactory<Ingredients, String>("Brand"));
        column5.setCellValueFactory(new PropertyValueFactory<Ingredients, Integer>("Amount"));
        column6.setCellValueFactory(new PropertyValueFactory<Ingredients, String>("Unit"));
        column7.setCellValueFactory(new PropertyValueFactory<Ingredients, String>("TypeDesc"));

        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery( "SELECT * FROM inventorysqltable;" );

            while ( rs.next() ) {
                String sku = rs.getString("SKU");
                String  name = rs.getString("Name");
                String  category = rs.getString("Category");
                String  brand = rs.getString("Brand");
                int  amount = rs.getInt("Amount");
                String  unit = rs.getString("Unit");
                String  typedesc = rs.getString("TypeDesc");

                invTableData.add(0, new Ingredients(sku,name,category,brand,amount,unit,typedesc));
            } //end while loop

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
        } //end catch

        invTable.getColumns().addAll(Arrays.asList(column1, column2, column3, column4, column5, column6, column7));
        invTable.setItems(invTableData);

        AnchorPane.setTopAnchor(invTable, 0.0);
        AnchorPane.setRightAnchor(invTable, 0.0);
        AnchorPane.setBottomAnchor(invTable, 0.0);
        AnchorPane.setLeftAnchor(invTable, 0.0);

        invPane.getChildren().addAll(invTable);
    } //end setTable

    /**
     * This method is for updating the table, so it displays the current values or
     * data held by the database.
     */
    @FXML
    public void refreshTable() {
        invTable.getItems().clear();
        Connection c = null;
        Statement stmt = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery( "SELECT * FROM inventorysqltable;" );

            while ( rs.next() ) {
                String sku = rs.getString("SKU");
                String  name = rs.getString("Name");
                String  category = rs.getString("Category");
                String  brand = rs.getString("Brand");
                int  amount = rs.getInt("Amount");
                String  unit = rs.getString("Unit");
                String  typedesc = rs.getString("TypeDesc");

                invTableData.add(0, new Ingredients(sku,name,category,brand,amount,unit,typedesc));
            } //end while loop

            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
        } //end catch

        invTable.setItems(invTableData);
    } //end refreshTable

    /**
     * This method is for creating the SKU of the items/ingredients.
     * This is always called every time the user adds items to the
     * inventory list and/or database.
     *
     * @return sku This returns the string containing the created SKU of the ingredient/item.
     */
    @FXML
    protected String generateSKU() {
        String sku = null;
        try{
            String categ = categField.getText().trim().toUpperCase();
            String name = nameField.getText().trim().toUpperCase();


            Integer range = 9999 - 0 + 1; // max - min + 1
            Integer rand = (int) (Math.random() * range);
            String formattedRand = String.format("%04d",rand);

            sku = String.valueOf(categ.charAt(0)) + String.valueOf(categ.charAt(categ.length()-1))
                    + String.valueOf(name.charAt(0)) + String.valueOf(name.charAt(name.length()-1)) + "-" + formattedRand;
        } catch (StringIndexOutOfBoundsException err){
            System.err.println("Invalid Input for SKU Generator"); // can be removed later
        } //end catch

        return sku;
    } //end generateSKU

    /**
     * This method is called when the user clicks on the 'Add Item' button.
     * This is for when the user wants to add new items/ingredients one by
     * one along with their descriptions.
     */
    @FXML
    public void onAddItem() {
        String sku = generateSKU();
        String nameText = nameField.getText().trim();
        String categText = categField.getText().trim();
        String brandText = brandField.getText().trim();
        String amtText = amtField.getText().trim();
        String unitText = unitBox.getSelectionModel().getSelectedItem();
        String typedescText = typedescField.getText().trim();
        Connection c = null;
        Statement stmt = null;

        if (nameText.length() != 0 && categText.length() != 0 && brandText.length() != 0 && amtText.length() != 0 && unitText.length() !=0 && typedescText.length() != 0) {
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
                c.setAutoCommit(false);

                stmt = c.createStatement();
                String sql = "INSERT INTO inventorysqltable (SKU,Name,Category,Brand,Amount,Unit,TypeDesc) " +
                        "VALUES ('" + sku + "', '" + nameText + "', '" + categText + "', '" +
                        brandText + "', " + amtText + ", '" + unitText + "', '" + typedescText + "' );";

                stmt.executeUpdate(sql);
                c.commit();

                refreshTable();
                stmt.close();
                c.close();
                clearFunction();
            } catch (Exception e) {
                System.err.println("Invalid Input!");
            } //end catch
        } else {
            System.err.println("Invalid Input!");
        } //end else

    } //end onAddItem

    /**
     * This method is called when the user clicks on the 'Add Stock' button.
     * This is for when the user wants to restock items/ingredients by bulk.
     */
    @FXML
    public void onAddStock() {
        String nameText = nameField.getText().trim();
        String categText = categField.getText().trim();
        String brandText = brandField.getText().trim();
        String amtText = amtField.getText().trim();
        Connection c = null;
        Statement stmt = null;

        if (nameText.length() != 0 && categText.length() != 0 && brandText.length() != 0 && amtText.length() != 0) {
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
                c.setAutoCommit(false);

                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM inventorysqltable WHERE Name = '" + nameText + "' AND Category = '" + categText + "' AND Brand = '" + brandText + "';");

                while (rs.next()) {
                    int ingAmt = rs.getInt("Amount");
                    int newAmt = ingAmt + Integer.parseInt(amtText);

                    String sql = "UPDATE inventorysqltable SET Amount = " + newAmt + " WHERE Name = '" + nameText + "' AND Category = '" + categText + "' AND Brand = '" + brandText + "';";
                    stmt.executeUpdate(sql);
                    c.commit();
                } //end while loop

                refreshTable();

                rs.close();
                stmt.close();
                c.close();
                clearFunction();
            } catch (Exception e) {
                System.err.println("Invalid Input!");
            } //end catch
        } else {
            System.err.println("Invalid Input!");
        } //end else

    } //end onAddStock

    /**
     * This method is called when the user clicks on the 'Add Stock (SKU)' button.
     * This is for when the user wants to restock items/ingredients by bulk
     * using their respective SKUs.
     */
    @FXML
    public void onAddStockSKU() {
        String skuText = skuField.getText().trim();
        String amtText = amtField.getText().trim();
        Connection c = null;
        Statement stmt = null;

        if (skuText.length() != 0 && amtText.length() != 0) {
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
                c.setAutoCommit(false);

                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM inventorysqltable WHERE SKU = '" + skuText + "';");

                int ingAmt = rs.getInt("Amount");
                int newAmt = ingAmt + Integer.parseInt(amtText);

                String sql = "UPDATE inventorysqltable SET Amount = " + newAmt + " WHERE SKU = '" + skuText + "';";
                stmt.executeUpdate(sql);
                c.commit();

                refreshTable();

                rs.close();
                stmt.close();
                c.close();
                clearFunction();
            } catch (Exception e) {
                System.err.println("Invalid Input!");
            } //end catch
        } else {
            System.err.println("Invalid Input!");
        } //end else

    } //end onAddStockSKU

    /**
     * This method is called when the user clicks on the 'Use Stock' button.
     * This is for when the user wants to use items/ingredients. The inventory
     * will then display the remaining amount or stock for that specific
     * item/ingredient.
     */
    @FXML
    public void onUseStock() {
        String nameText = nameField.getText().trim();
        String categText = categField.getText().trim();
        String brandText = brandField.getText().trim();
        String amtText = amtField.getText().trim();
        Connection c = null;
        Statement stmt = null;

        if (nameText.length() != 0 && categText.length() != 0 && brandText.length() != 0 && amtText.length() != 0) {
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
                c.setAutoCommit(false);

                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM inventorysqltable WHERE Name = '" + nameText + "' AND Category = '" + categText + "' AND Brand = '" + brandText + "';");

                while (rs.next()) {
                    int ingAmt = rs.getInt("Amount");
                    int newAmt = ingAmt - Integer.parseInt(amtText);

                    String sql = "UPDATE inventorysqltable SET Amount = " + newAmt + " WHERE Name = '" + nameText + "' AND Category = '" + categText + "' AND Brand = '" + brandText + "';";
                    stmt.executeUpdate(sql);
                    c.commit();
                } //end while loop

                refreshTable();

                rs.close();
                stmt.close();
                c.close();
                clearFunction();
            } catch (Exception e) {
                System.err.println("Invalid Input!");
            } //end catch
        } else {
            System.err.println("Invalid Input!");
        } //end else

    } //end onUseStock

    /**
     * This method is called when the user clicks on the 'Use Stock (SKU)' button.
     * This is for when the user wants to use an item/ingredient by entering their
     * respective SKU. The inventory will then display the remaining amount or
     * stock for that specific item/ingredient.
     */
    @FXML
    public void onUseStockSKU() {
        String skuText = skuField.getText().trim();
        String amtText = amtField.getText().trim();
        Connection c = null;
        Statement stmt = null;

        if (skuText.length() != 0 && amtText.length() != 0) {
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
                c.setAutoCommit(false);

                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM inventorysqltable WHERE SKU = '" + skuText + "';");

                int ingAmt = rs.getInt("Amount");
                int newAmt = ingAmt - Integer.parseInt(amtText);

                String sql = "UPDATE inventorysqltable SET Amount = " + newAmt + " WHERE SKU = '" + skuText + "';";
                stmt.executeUpdate(sql);
                c.commit();

                refreshTable();

                rs.close();
                stmt.close();
                c.close();
                clearFunction();
            } catch (Exception e) {
                System.err.println("Invalid Input!");
            } //end catch
        } else {
            System.err.println("Invalid Input!");
        } //end else

    } //end onUseStockSKU

    /**
     * This method is called when the user clicks on the 'Delete' button.
     * This is for when the user wants to delete an item/ingredient
     * in the inventory.
     */
    @FXML
    public void onDelete() {
        String nameText = nameField.getText().trim();
        String categText = categField.getText().trim();
        String brandText = brandField.getText().trim();
        String typedescText = typedescField.getText().trim();
        Connection c = null;
        Statement stmt = null;

        if (nameText.length() != 0 && categText.length() != 0 && brandText.length() != 0 && typedescText.length() != 0) {
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
                c.setAutoCommit(false);

                stmt = c.createStatement();
                String sql = "DELETE FROM inventorysqltable WHERE Name = '" + nameText + "' AND Category = '" + categText + "' AND Brand = '" + brandText +  "' AND TypeDesc = '" + typedescText + "';";
                stmt.executeUpdate(sql);
                c.commit();

                refreshTable();
                stmt.close();
                c.close();
                clearFunction();
            } catch (Exception e) {
                System.err.println("Invalid Input!");
            } //end catch
        } else {
            System.err.println("Invalid Input!");
        } //end else

    } //end onDelete

    /**
     * This method is called when the user clicks on the 'Delete (SKU)' button.
     * This is for when the user wants to delete an item/ingredient using their
     * respective SKU.
     */
    @FXML
    public void onDeleteSKU() {
        String skuText = skuField.getText().trim();
        Connection c = null;
        Statement stmt = null;

        if (skuText.length() != 0) {
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
                c.setAutoCommit(false);

                stmt = c.createStatement();
                String sql = "DELETE FROM inventorysqltable WHERE SKU = '" + skuText + "';";
                stmt.executeUpdate(sql);
                c.commit();

                refreshTable();
                stmt.close();
                c.close();
                clearFunction();
            } catch (Exception e) {
                System.err.println("Invalid Input!");
            } //end catch
        } else {
            System.err.println("Invalid Input!");
        } //end else

    } //end onDeleteSKU

    /**
     * This method, along with clearFunction method, is called when the
     * user clicks on the 'Clear' button. This is for when the user wants
     * to clear or reset the text fields.
     */
    @FXML
    public void onClear() {
        clearFunction();
    }

    public void clearFunction(){
        skuField.setText("");
        nameField.setText("");
        categField.setText("");
        brandField.setText("");
        amtField.setText("");
        unitBox.getSelectionModel().clearSelection();
        typedescField.setText("");
        csvfileField.setText("");
    } //end ClearFunction

    /**
     * This method is called when the user clicks on the 'Close' button.
     * This closes the stage containing the inventory list and/or database.
     *
     * @param event This object calls the inherited method getSource.
     */
    @FXML
    public void onInventoryClose(ActionEvent event) throws IOException {
        FXMLLoader menu = new FXMLLoader(MainController.class.getResource("homepage.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(menu.load());
        scene.getStylesheets().add(Main.class.getResource("style.css").toExternalForm());
//        stage.initOwner(Main.primaryStage);
        stage.setResizable(false);
//        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle(" La TaCode Restaurant Inventory");
        stage.setScene(scene);
        stage.show();
    } //end onInventoryClose

    /**
     * This method is called when the user clicks on the 'Import' button.
     * This is for when the user wants to add items/ingredients by bulk
     * using the import functionality. The file type of the imports are
     * in .csv format.
     *
     * @throws FileNotFoundException On inaccessible files.
     */
    @FXML
    public void onBulkAdd() throws FileNotFoundException {
        String csvText = csvfileField.getText().trim();
        System.out.println(csvText);
        File filename = new File(csvText);
        try {
            Scanner sc = new Scanner(filename);
            sc.nextLine(); // Move file pointer to next line to skip titles.
            while(sc.hasNext()) {
                StringTokenizer token = new StringTokenizer(sc.nextLine(),",");
                String sku = null;
                String nameText= null;
                String categText= null;
                String brandText= null;
                String wtvolText= null;
                String unitText = null;
                String typedescText= null;

                while(token.hasMoreElements()) {
                    sku = token.nextElement().toString();
                    nameText = token.nextElement().toString();
                    categText = token.nextElement().toString();
                    brandText = token.nextElement().toString();
                    wtvolText = token.nextElement().toString();
                    unitText = token.nextElement().toString();
                    typedescText = token.nextElement().toString();
                } //end nested while loop

                /* Adding the tokens to the database*/
                Connection c = null;
                Statement stmt = null;
                try {
                    Class.forName("org.sqlite.JDBC");
                    c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
                    c.setAutoCommit(false);

                    stmt = c.createStatement();

                    String sql = "INSERT INTO inventorysqltable (SKU,Name,Category,Brand,Amount,Unit,TypeDesc) " +
                            "VALUES ('" + sku + "', '" + nameText + "', '" + categText + "', '" +
                            brandText + "', " + wtvolText + ", '"+ unitText+ "', '" + typedescText + "' );";

                    stmt.executeUpdate(sql);
                    c.commit();

                    refreshTable();
                    stmt.close();
                    c.close();
                    clearFunction();
                } catch (Exception e) {
                    e.printStackTrace();
                    System.err.println("Invalid Input!");
                } //end catch
            } //end while loop

        } catch (FileNotFoundException err) {
            System.err.println("File Not Found.");
        } //end catch

    } //end onBulkAdd

    /**
     * This method is called when the user clicks on the search button (🔍︎)
     * after entering a string in the search text field.
     */
    public void onSrchItem() {
        invTable.getItems().clear();
        String srchText = srchField.getText().trim();
        Connection c = null;
        Statement stmt = null;

        if (srchText.length() != 0) {
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:inventorySQL.db");
                c.setAutoCommit(false);

                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM inventorysqltable WHERE SKU LIKE '%" + srchText +
                        "%' OR Name LIKE '%" + srchText + "%' OR Category LIKE '%" + srchText + "%' OR Brand LIKE '%" + srchText +
                        "%' OR Amount LIKE '%" + srchText + "%' OR Unit LIKE '%" + srchText + "%' OR TypeDesc LIKE '%" + srchText + "%';");

                while (rs.next()) {
                    String sku = rs.getString("SKU");
                    String name = rs.getString("Name");
                    String category = rs.getString("Category");
                    String brand = rs.getString("Brand");
                    int amount = rs.getInt("Amount");
                    String unit = rs.getString("Unit");
                    String typedesc = rs.getString("TypeDesc");

                    invTableData.add(0, new Ingredients(sku, name, category, brand, amount, unit, typedesc));
                } //end while loop

                rs.close();
                stmt.close();
                c.close();
            } catch (Exception e) {
                System.err.println(e.getClass().getName() + ": " + e.getMessage());
            } //end catch

            invTable.setItems(invTableData);
        } else if (srchText.length() == 0) {
            refreshTable();
        } else {
            System.err.println("Invalid Input!");
        } //end else

    }//end onSrchItem

    /**
     * This method is called when the user clicks on the 'Export' button.
     * This is for when the user wants to export the current inventory
     * stock as a .csv file.
     *
     * @throws IOException On input error.
     */
    public void exportCSV() throws IOException {
        FileWriter fileWriter = new FileWriter("export.csv");

        arr = new ArrayList<>();
        arr.addAll(invTableData);

        try{
            fileWriter.write("SKU,Name,Category,Brand,Amount,Unit,TypeDesc\n");
            for(int i = 0;i<arr.size();i++){
                fileWriter.write(arr.get(i).getSKU() + ","+ arr.get(i).getName()+ ","+ arr.get(i).getCategory()+ ","+ arr.get(i).getBrand()+ ","+ arr.get(i).getAmount()+ ","+ arr.get(i).getUnit()+ ","+ arr.get(i).getTypeDesc()+"\n");
            }

            fileWriter.close();
            System.out.println("Successfully exported inventory to export.csv");
        }catch (IOException e){
            System.err.println("An error occurred. Please Try Again.");
        }
    }
} //end InventoryController
