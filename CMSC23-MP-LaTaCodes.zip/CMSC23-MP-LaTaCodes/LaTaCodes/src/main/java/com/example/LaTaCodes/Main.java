package com.example.LaTaCodes;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {

    /**
     * This is the method responsible for setting up the application's primary stage and first scene
     * — the homepage.
     *
     * @param primaryStage This is the primary stage for the application, specifically for displaying the homepage.
     * @throws IOException On input error.
     */
    @Override
    public void start(Stage primaryStage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("homepage.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        scene.getStylesheets().add(Main.class.getResource("style.css").toExternalForm());
        primaryStage.setResizable(false);
        primaryStage.setTitle("La TaCodes Restaurant Inventory");
        primaryStage.setScene(scene);
        primaryStage.show();

    } //end start

    /**
     * This is the main method which makes use of the start method and launches the application.
     *
     * @param args Unused.
     */
    public static void main(String[] args) {
        launch();
    }

} //end Main