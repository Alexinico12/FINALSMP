package com.example.LaTaCodes;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


import java.io.IOException;


public class MainController {


    @FXML
    private Stage stage;


    /**
     * This method is called when the user clicks on the 'Inventory' button
     * in the homepage. This directs the user to the restaurant's inventory
     * list or database.
     *
     * @param event This object calls the inherited method getSource.
     * @throws IOException On input error.
     */
    @FXML
    protected void switchToInventory(ActionEvent event) throws IOException {
        FXMLLoader inv = new FXMLLoader(MainController.class.getResource("inventory.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        AnchorPane invFXML = (AnchorPane) inv.load();
        Scene scene = new Scene(invFXML);
        scene.getStylesheets().add(Main.class.getResource("style.css").toExternalForm());
        stage.setResizable(false);
        stage.setTitle("INVENTORY");
        stage.setScene(scene);
        stage.show();


        InventoryController iControl = inv.getController();
        iControl.setTable();
        iControl.setInvCSS();
    } //end switchToInventory


    /**
     * This method is called when the user clicks on the 'Menu' button
     * in the homepage. This directs the user to the display menu.
     *
     * @param event This object calls the inherited method getSource.
     * @throws IOException On input error.
     */
    @FXML
    protected void switchToMenu(ActionEvent event) throws IOException {
        FXMLLoader menu = new FXMLLoader(MainController.class.getResource("display-menu.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(menu.load());
        scene.getStylesheets().add(Main.class.getResource("style.css").toExternalForm());
        stage.setResizable(false);
        stage.setTitle("MENU");
        stage.setScene(scene);
        stage.show();


    } //end switchToMenu


    /**
     * This method is called when the user clicks on the 'Exit' button
     * in the homepage. This is for when the user wants to close the
     * application.
     *
     * @param event This object calls the inherited method getSource.
     */
    @FXML
    public void onHomePageClose(ActionEvent event){
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    } //end onHomePageClose


    /**
     * This method is called when the user clicks on the 'Back to Home'
     * button in the display menu. This is for when the user wants to
     * go back to the homepage.
     *
     * @param event This object calls the inherited method getSource.
     * @throws IOException On input error.
     */
    @FXML
    public void onMenuClose(ActionEvent event) throws IOException {
        FXMLLoader menu = new FXMLLoader(MainController.class.getResource("homepage.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(menu.load());
        scene.getStylesheets().add(Main.class.getResource("style.css").toExternalForm());
        stage.setResizable(false);
        stage.setTitle("La TaCoodes Restaurant Inventory");
        stage.setScene(scene);
        stage.show();
    } //end onInventoryClose
} //end MainController

