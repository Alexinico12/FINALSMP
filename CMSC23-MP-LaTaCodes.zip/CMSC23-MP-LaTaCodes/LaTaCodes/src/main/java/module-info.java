module com.example.cs23_mp_rogori {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.LaTaCodes to javafx.fxml;
    exports com.example.LaTaCodes;
}